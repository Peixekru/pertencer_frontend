
// export features declared elsewhere
export { Fn, Vr };

// export individual features (can export var, let,
// const, function, class)

export let Vr = 'teste';
export function Fn() {
  console.log('teste')
}